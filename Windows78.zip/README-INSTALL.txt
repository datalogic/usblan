USBLAN Installation             
*******************

Please read License.txt for the end user license agreement.

For best results, run the setup.bat file BEFORE plugging your device in.

The setup.bat script uses DPInst from Microsoft to pre-install the drivers
required for your device.

The dpinst program (which is called by setup.bat) creates a USBLAN entry in the 
Programs and Features list. Uninstalling this program/feature will uninstall USBLAN

Installed devices may be removed using the Device Manager program.  There is an
option in the Device Manager to "remove driver software". This option will remove
USBLAN and all device instances from the registry.

These two methods of removing USBLAN should not be mixed: if one if used, the other 
should not be.

More Information

    - http://usblan.belcarra.com/p/updating-usblan.html
    - http://usblan.belcarra.com/p/uninstalling.html

