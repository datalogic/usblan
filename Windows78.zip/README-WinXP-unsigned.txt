Windows XP Un-Signed                                            Stuart Lynne
Belcarra                                        Thu May 31 13:05:03 PDT 2018 


The vista directory contains a copy of the USBLAN driver that is not signed.

It may be used on systems before Windows 7 (Vista and WinXP) that do not
require signed drivers.



