Belcarra USBLAN for Microsoft Windows OEM Distribution Kit 
Belcarra Technologies 2005

This package contains the Belcarra USBLAN driver for Windows 7 and Windows 8.

The driver package is configured to your requirements using the options from the
following spreadsheet, which is also included in this kit:

        datalogic-20180212.xls

The following zip file contains the re-distributable End-User Kit:

        datalogic-20180212-win78.zip

These drivers are signed by Belcarra and will will install on Windows 7 and 
Windows 8 with an Unknown Publisher Warning.


End-User Redistribution Kit Contents
************************************

Archive:  datalogic-20180212-win78.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
    85611  06-25-2018 16:33   README-Windows7-SecurityUpdate-KB30339290.pdf
      925  06-25-2018 16:33   README-INSTALL.txt
      346  06-25-2018 16:33   README-WinXP-unsigned.txt
     4888  06-25-2018 16:33   License.txt
     4493  06-25-2018 16:33   setup.bat
  1054448  06-25-2018 16:33   dpinst-x64.exe
   929008  06-25-2018 16:33   dpinst-x86.exe
        0  06-25-2018 16:32   vista/amd64/
   962560  06-25-2018 16:32   vista/amd64/dlgblan.pdb
   177152  06-25-2018 16:32   vista/amd64/dlgblan.sys
    10831  06-25-2018 16:33   vista/datalogic.inf
        0  06-25-2018 16:32   vista/i386/
   978944  06-25-2018 16:32   vista/i386/dlgblan.pdb
   149504  06-25-2018 16:32   vista/i386/dlgblan.sys
        0  06-25-2018 16:32   win7/amd64/
  1011712  06-25-2018 16:32   win7/amd64/dlgblan.pdb
   190928  06-25-2018 16:33   win7/amd64/dlgblan.sys
     9838  06-25-2018 16:33   win7/datalogic.cat
     9661  06-25-2018 16:32   win7/datalogic.inf
        0  06-25-2018 16:32   win7/i386/
  1028096  06-25-2018 16:32   win7/i386/dlgblan.pdb
   163280  06-25-2018 16:33   win7/i386/dlgblan.sys
        0  06-25-2018 16:32   win8/amd64/
  1036288  06-25-2018 16:32   win8/amd64/dlgblan.pdb
   191952  06-25-2018 16:33   win8/amd64/dlgblan.sys
    10094  06-25-2018 16:33   win8/datalogic.cat
     9661  06-25-2018 16:33   win8/datalogic.inf
        0  06-25-2018 16:32   win8/i386/
  1060864  06-25-2018 16:32   win8/i386/dlgblan.pdb
   164304  06-25-2018 16:33   win8/i386/dlgblan.sys
---------                     -------
  9245388                     30 files



Installation
************

There are several common scenarios for installation of these drivers.

When a USB Device is plugged in Windows will do the following:

    1. Look for a previously used driver
    2. Look for a pre-loaded but not in use driver
    3. Look for the driver in Windows Update
    4. Fail

If Windows fails to find a driver the user can interact with the Device Manager
to direct Windows to look for a driver in a specific place, typically by
browsing to a folder containing the drivers.

A. Pre-Install from Disk 
************************

The drivers can be pre-installed using the Microsoft DPInst utility. This is
done by using the setup.bat script in the archive. DPInst copies the drivers to
an archive location. Later Windows will be able to find the drivers when your
device is plugged in.

For more information see:

    http://www.microsoft.com/whdc/driver/install/difxtools.mspx

This can be done with both the cross-signed kit from Belcarra and the optional
Microsoft Signed kit

B. Directed Install from Disk
*****************************

Older versions of Windows (e.g. Windows XP) allow for the user to specify the
location of the drivers during the initial installation process (by browsing to
where the zip archive is unpacked).

 N.B New versions of Windows (e.g. Windows 7) do not allow this in the initial
 installation phase. 

If Windows does not find the driver (because neither of the first two
installation options was used) the driver can be installed by using the Windows
Device Manager.

Navigate to Control Panel / System / Hardware / Device manager and find the
"unknown device". Then "update drivers" can be used to find and install the
drivers from the CD or directory containing the driver installation files
(contents of the driver000 directory).

This method can also be used to update drivers, in that case using the uninstall
or update menu items.

This can be done with both the cross-signed kit from Belcarra and the optional
Microsoft Signed kit


More Information
****************

More information can be found on the websites:

    - http://www.belcarra.com/
    - http://usblan.belcarra.com/


--
Last updated May 2017


